<div
	class="mkd-portfolio-filter-holder <?php echo esc_attr($masonry_filter) ?>" <?php //servicemaster_mikado_inline_style($filter_styles); ?>>
	<div class="mkd-portfolio-filter-holder-inner">
		<?php print $filter_categories; ?>
	</div>
</div>