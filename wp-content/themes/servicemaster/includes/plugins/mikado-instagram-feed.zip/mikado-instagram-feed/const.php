<?php

define('MIKADO_INSTAGRAM_FEED_REL_PATH', dirname(plugin_basename(__FILE__)));